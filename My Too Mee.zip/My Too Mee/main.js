
var typed = new Typed(".typewriter-text ",
    {
        strings: [" ",
            "Web Developer",
            " ",
            "Web Designer",
            " ",
            "Freelancer",
            " ",
            "Travel Blogger",
            " ",
            " Youtuber"
        ],
        typeSpeed: 100,
        backSpeed: 60,
        loop:true,
        backDelay: 1000
        
    }
)